2007-06-20  Arliss Whiteside

  * added Definitions 1.1.0 (OGC 06-023r1)
  * changed to use relative path
  * changed directory separator character to "/"

