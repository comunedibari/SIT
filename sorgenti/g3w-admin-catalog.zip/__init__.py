default_app_config = 'catalog.apps.CatalogConfig'
