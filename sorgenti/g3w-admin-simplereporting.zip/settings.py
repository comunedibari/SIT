# coding=utf-8
""""
    Default settings for simplereporting module
.. note:: This program is free software; you can redistribute it and/or modify
    it under the terms of the Mozilla Public License 2.0.

"""

__author__ = 'lorenzetti@gis3w.it'
__date__ = '2023-06-21'
__copyright__ = 'Copyright 2015 - 2023, Gis3w'
__license__ = 'MPL 2.0'

SIMPLEREPORTING_TOOL_POSITION = 'sidebar' # May be `mapcontrol`