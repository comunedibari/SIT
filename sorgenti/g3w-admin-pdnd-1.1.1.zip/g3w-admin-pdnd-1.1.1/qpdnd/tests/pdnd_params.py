# For client assertion
# --------------------
KID = "oXWj41Rf_3n8ZEkYL_D1FsZwf9ij1_D7-xpgd4cPjbY"
ALG = "RS256"
TYP = "JWT"
ISSUER = "45a087f8-6806-43f6-8431-d15fa1c98f0c"
SUBJECT = "45a087f8-6806-43f6-8431-d15fa1c98f0c"
AUDIENCE = "auth.uat.interop.pagopa.it/client-assertion"
# PURPOSEID = "14d96e23-0b2d-4a89-9706-a2252942ff4e"
PURPOSEID = "a338d652-7aa3-4083-81e7-71d7328be05c" # areepercorsedalfuoco
PRIVKEY = "pdnd/keys/g3w-coll-keypair.rsa.priv"
TOKENOAUTH_ENDPOINT = "https://auth.uat.interop.pagopa.it/token.oauth2"