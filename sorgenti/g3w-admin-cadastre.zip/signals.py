import django.dispatch

# Dashboard widget
load_cadastre_dashboard_widgets = django.dispatch.Signal()