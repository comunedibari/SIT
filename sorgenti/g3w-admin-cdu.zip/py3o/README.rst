For run py3o stack:

::

    docker-compose up -d

