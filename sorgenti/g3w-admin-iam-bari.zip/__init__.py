# my_app/__init__.py
default_app_config = 'iam_bari.apps.IamBariConfig'
