# G3W-SUITE for Comune di BARI- PLANETEK
## Update from v3.2.x version

## Installed modules
* core
* editing
* caching
* qplotly
* filemanager
* law
* cdu
* cadastre
* iam_bari
* geolocalxls
* portal (for Altamura)
