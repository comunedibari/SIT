"""
Add your API routes here.
"""
# API ROOT: /OWS/

__author__    = 'lorenzetti@gis3w.it'
__copyright__ = 'Copyright 2015 - 2023, Gis3w'
__license__   = "MPL 2.0"

urlpatterns = []