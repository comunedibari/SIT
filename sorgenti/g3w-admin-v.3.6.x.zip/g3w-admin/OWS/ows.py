
class OWSRequestHandlerBase(object):

    def __init__(self):
        pass

    def doRequest(self):
        pass