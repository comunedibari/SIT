/**
 * @file
 * @author    Walter Lorenzetti <lorenzetti@gis3w.it>
 * @copyright 2016-02-18, Gis3w
 * @license   MPL 2.0
 */

/**
 * @TODO check if deprecated (+ if not, prefer "const $m;" as declaration)
 */
var $m;

$(document).ready(function(){
    ga.bootstrap();
});
