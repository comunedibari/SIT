$('.fm-container').richFilemanager({
    // configuration options not included in .json configuration file, see:
    // https://github.com/servocoder/RichFilemanager/wiki/Configuration-options#client-side-configuration
    baseUrl: '/static/RichFilemanager',
});
