# coding=utf-8
"""
    Filemanager config settings properties
.. note:: This program is free software; you can redistribute it and/or modify
     it under the terms of the Mozilla Public License 2.0.
"""

__author__ = 'lorenzetti@gis3w.it'
__date__ = '2019-03-14'
__copyright__ = 'Copyright 2019, GIS3W'


FILEMANAGER_MAX_UPLOAD_N_FILES = 10
