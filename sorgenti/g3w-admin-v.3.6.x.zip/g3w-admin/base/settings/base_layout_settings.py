ADMINLTE_SKIN_DEFAULT = 'skin-yellow'
ADMINLTE_LAYOUT_OPTION = 'sidebar-mini'
G3WSUITE_CUSTOM_STATIC_URL = None
G3WSUITE_CUSTOM_CSS = []
G3WSUITE_CUSTOM_JS = []
G3WSUITE_MAIN_LOGO = 'img/g3wsuite_logo.png'
G3WSUITE_RID_LOGO = 'img/g3wsuite_logo_rid.png'
G3WSUITE_LOGIN_LOGO = 'img/g3wsuite_logo_h48.png'
G3WSUITE_POWERD_BY = True

G3W_CLIENT_RIGHT_PANEL = {
    'width': 33
}