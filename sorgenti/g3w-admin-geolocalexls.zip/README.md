# G3W-ADMIN-GEOLOCALEXLS 
## G3W-ADMIN module for geolocation of XLS and CSV