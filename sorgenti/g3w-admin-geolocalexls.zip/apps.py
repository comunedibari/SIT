from django.apps import AppConfig


class GeolocalexlsConfig(AppConfig):
    name = 'geolocalexls'
